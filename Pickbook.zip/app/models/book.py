from sqlalchemy import Column, Date, DateTime, Integer, String, Text, UniqueConstraint
from sqlalchemy.sql import func
from app.core.database import Base

class Book(Base):

    __tablename__ = "books"

    id = Column(Integer, primary_key=True, index=True)

    source = Column(String)

    title = Column(String)

    author = Column(String)

    genre = Column(String)

    cover = Column(String)

    download = Column(String)

    language = Column(String)

    synopsis = Column(Text, nullable=True)

    chapters_count = Column(Integer, nullable=True)

    chapter_content = Column(Text, nullable=True)

    created_at = Column(DateTime(timezone=True), server_default=func.now())


class Profile(Base):

    __tablename__ = "profiles"

    id = Column(String, primary_key=True, index=True)

    email = Column(String, unique=True, index=True, nullable=False)

    email_verified = Column(Integer, default=0, nullable=False)

    email_verification_token = Column(String, nullable=True, index=True)

    email_verification_sent_at = Column(DateTime(timezone=True), nullable=True)

    username = Column(String, unique=True, index=True, nullable=True)

    current_plan = Column(String, default="free", nullable=False)

    paystack_customer_id = Column(String, nullable=True)

    subscription_expiry = Column(DateTime(timezone=True), nullable=True)

    referral_code = Column(String, unique=True, index=True, nullable=True)

    referred_by = Column(String, nullable=True)

    referral_bonus_claimed_at = Column(DateTime(timezone=True), nullable=True)

    signup_fingerprint = Column(String, nullable=True, index=True)

    streak_count = Column(Integer, default=0, nullable=False)

    last_read_date = Column(Date, nullable=True)

    created_at = Column(DateTime(timezone=True), server_default=func.now())


class Coupon(Base):

    __tablename__ = "coupons"

    id = Column(Integer, primary_key=True, index=True)

    code = Column(String, unique=True, index=True, nullable=False)

    discount_type = Column(String, nullable=False)

    discount_value = Column(Integer, nullable=False)

    plan_target = Column(String, default="standard", nullable=False)

    max_uses = Column(Integer, default=1, nullable=False)

    used_count = Column(Integer, default=0, nullable=False)

    expiry_date = Column(DateTime(timezone=True), nullable=True)

    created_at = Column(DateTime(timezone=True), server_default=func.now())


class CouponClaim(Base):

    __tablename__ = "coupon_claims"

    __table_args__ = (
        UniqueConstraint("user_id", "coupon_id", name="uq_coupon_claim_user_coupon"),
    )

    id = Column(Integer, primary_key=True, index=True)

    user_id = Column(String, nullable=False, index=True)

    coupon_id = Column(Integer, nullable=False, index=True)

    fingerprint = Column(String, nullable=True, index=True)

    claimed_at = Column(DateTime(timezone=True), server_default=func.now())


class PaystackEvent(Base):

    __tablename__ = "paystack_events"

    id = Column(Integer, primary_key=True, index=True)

    reference = Column(String, unique=True, nullable=False, index=True)

    user_id = Column(String, nullable=False, index=True)

    plan = Column(String, nullable=False)

    amount = Column(Integer, nullable=False)

    paystack_fee = Column(Integer, default=0, nullable=False)

    net_amount = Column(Integer, default=0, nullable=False)

    referral_code = Column(String, nullable=True, index=True)

    partner_code = Column(String, nullable=True, index=True)

    created_at = Column(DateTime(timezone=True), server_default=func.now())


class PendingPayment(Base):

    __tablename__ = "pending_payments"

    reference = Column(String, primary_key=True, index=True)

    kind = Column(String, nullable=False, default="subscription")

    user_id = Column(String, nullable=True, index=True)

    plan = Column(String, nullable=True)

    amount = Column(Integer, nullable=False)

    metadata_json = Column(Text, nullable=True)

    processed_at = Column(DateTime(timezone=True), nullable=True)

    created_at = Column(DateTime(timezone=True), server_default=func.now())


class ReadingActivity(Base):

    __tablename__ = "reading_activity"

    __table_args__ = (
        UniqueConstraint("user_id", "read_date", name="uq_reading_activity_user_date"),
    )

    id = Column(Integer, primary_key=True, index=True)

    user_id = Column(String, nullable=False, index=True)

    read_date = Column(Date, nullable=False, index=True)

    chapters_read = Column(Integer, default=1, nullable=False)


class PartnerDeal(Base):

    __tablename__ = "partner_deals"

    id = Column(String, primary_key=True, index=True)

    name = Column(String, nullable=False)

    email = Column(String, unique=True, index=True, nullable=False)

    referral_code = Column(String, unique=True, index=True, nullable=False)

    status = Column(String, default="active", nullable=False)

    created_at = Column(DateTime(timezone=True), server_default=func.now())


class InvestorDeal(Base):

    __tablename__ = "investor_deals"

    id = Column(String, primary_key=True, index=True)

    name = Column(String, nullable=False)

    email = Column(String, unique=True, index=True, nullable=False)

    plan_type = Column(String, nullable=False)

    amount = Column(Integer, nullable=False)

    roi_cap_multiplier = Column(Integer, default=2, nullable=False)

    status = Column(String, default="pending_payment", nullable=False)

    created_at = Column(DateTime(timezone=True), server_default=func.now())
